#!/usr/bin/env python3
"""
Evaluation harness for ARM steering.

Compares baseline (no steering) vs. ARM steering across a sweep of steering strengths
on three tasks:

1) JSON adherence: Build manifold from fixed corpus of JSON examples; steer toward
   average resonance signature. Measure valid JSON adherence with required keys.

2) Style transfer: Use control-vector steering (pos vs neg exemplars). Score via
   heuristic lexical markers.

3) Manifold-signature: Build manifold from style exemplars; steer toward target
   signature. Measure signature cosine similarity and report topology metrics
   (n_clusters, silhouette).

Outputs:
- results CSV per task under arm_output/
- dose–response plots (score vs. strength) under arm_output/

This harness uses both control-vector and manifold-signature steering modes.
JSON and manifold-signature evals build full topology; style transfer uses control vectors only.
"""

import os
import csv
from dataclasses import dataclass
from typing import List, Dict, Any, Tuple

import numpy as np
import matplotlib.pyplot as plt

from arm_library.core.arm_mapper import ARMMapper
from arm_library.utils.config import ARMConfig


# ------------------------- Utilities -------------------------

OUTPUT_DIR = "arm_output"
os.makedirs(OUTPUT_DIR, exist_ok=True)


def safe_json_adherence_score(text: str, required_keys: List[str]) -> float:
    """Return 1.0 if text contains a valid JSON object with all required keys, else 0.0.
    More lenient heuristic:
      - Find minimal brace blocks {...}
      - Try json.loads; if that fails, lightly normalize keys/quotes and try again
    """
    import json
    import re

    # Find minimal brace substrings
    candidates = re.findall(r"\{[^{}]*\}", text, flags=re.DOTALL)
    if not candidates:
        return 0.0

    def try_parse(s: str):
        try:
            return json.loads(s)
        except Exception:
            return None

    for cand in candidates:
        obj = try_parse(cand)
        if obj is None:
            # Light normalization: quote bare keys, unify quotes, remove duplicate quotes
            s = re.sub(r"(\b\w+\b)\s*:", r'"\1":', cand)
            s = s.replace("'", '"')
            s = s.replace('""', '"')
            obj = try_parse(s)
        if isinstance(obj, dict):
            if all(k in obj for k in required_keys):
                return 1.0
    return 0.0


def simple_style_score(text: str, positive_markers: List[str], negative_markers: List[str]) -> float:
    """Heuristic style score: (#pos_markers - #neg_markers) normalized by length.
    Range roughly in [-1, 1]."""
    text_lower = text.lower()
    pos = sum(text_lower.count(m.lower()) for m in positive_markers)
    neg = sum(text_lower.count(m.lower()) for m in negative_markers)
    length_norm = max(1, len(text_lower) // 50)
    return (pos - neg) / float(length_norm)


def plot_dose_response(x_values: List[float], y_values: List[float], title: str, ylabel: str, filename: str):
    plt.figure(figsize=(6, 4))
    plt.plot(x_values, y_values, marker='o')
    plt.title(title)
    plt.xlabel('Steering strength')
    plt.ylabel(ylabel)
    plt.grid(True, alpha=0.3)
    path = os.path.join(OUTPUT_DIR, filename)
    plt.tight_layout()
    plt.savefig(path, dpi=150)
    plt.close()
    return path


# ------------------------- Harness -------------------------

@dataclass
class EvalConfig:
    model_name: str = "gpt2-medium"
    layer_to_probe: int = 3
    max_tokens: int = 30
    temperature: float = 0.8
    strengths: Tuple[float, ...] = (0.0, 0.5, 1.0, 1.5, 2.0)
    enable_constrained_json: bool = True
    json_seed_file: str = "test-data/json_test.txt"
    json_num_shots: int = 2


def build_arm(config: EvalConfig) -> ARMMapper:
    arm_config = ARMConfig(
        model_name=config.model_name,
        layer_to_probe=config.layer_to_probe,
        n_seeds=3,
        probes_per_seed=2,
        steps_per_probe=2,
        eps=0.03,
        n_modes=4,
    )
    return ARMMapper(arm_config)


def quick_signature(arm: ARMMapper, text: str, k: int = 2, steps: int = 3, eps: float = 0.02):
    """Compute a lightweight resonance signature for arbitrary text."""
    A = arm.collect_activation_matrix(text, k=k, steps=steps, eps=eps)
    return arm.resonance_analyzer.resonance_signature(A)


def topology_summary(manifold: Dict[str, Any]) -> Dict[str, Any]:
    """Compute simple topology/cluster summary metrics from manifold results."""
    from sklearn.metrics import silhouette_score

    out = {}
    try:
        X = manifold['graph_data']['feature_vectors']
        labels = np.array(manifold['clustering_data']['cluster_labels'])

        # Silhouette only valid if >1 cluster and each cluster has >1 sample
        if len(np.unique(labels)) > 1 and len(X) >= 3:
            out['silhouette'] = float(silhouette_score(X, labels))
        else:
            out['silhouette'] = None

        sizes = [int(np.sum(labels == i)) for i in range(manifold['clustering_data']['n_clusters'])]
        out['cluster_sizes'] = sizes
        out['n_clusters'] = int(manifold['clustering_data']['n_clusters'])
    except Exception:
        out['silhouette'] = None
    return out


def eval_manifold_signature(arm: ARMMapper, cfg: EvalConfig,
                            pos: List[str], neg: List[str], request: str,
                            target_idx: int = 0) -> Dict[str, Any]:
    """Sweep manifold-signature steering strength and measure signature similarity lift."""
    # Build manifold from exemplars
    manifold_prompts = pos + neg
    manifold = arm.map_latent_manifold(manifold_prompts)

    # Target is one of the positive exemplars by default
    target_sig = manifold['seed_analyses'][target_idx]['resonance_signature']['s_norm']

    results = []
    for s in cfg.strengths:
        if s > 0:
            generated = arm.steer_generation_toward_signature(
                prompt=request,
                target_signature=target_sig,
                max_length=cfg.max_tokens,
                temperature=cfg.temperature,
                steering_strength=s,
            )
        else:
            gen = arm.create_controlled_generator()
            generated = gen.generate_with_steering(
                prompt=request,
                max_length=cfg.max_tokens,
                temperature=cfg.temperature,
                do_sample=True,
            )

        sig = quick_signature(arm, generated)
        m = min(len(sig['s_norm']), len(target_sig))
        denom = (np.linalg.norm(sig['s_norm'][:m]) * np.linalg.norm(target_sig[:m]) + 1e-12)
        cosine = float(np.dot(sig['s_norm'][:m], target_sig[:m]) / denom)

        results.append({
            'strength': s,
            'signature_cosine': cosine,
            'output': generated,
        })

    # Save CSV
    csv_path = os.path.join(OUTPUT_DIR, "manifold_signature_results.csv")
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["strength", "signature_cosine", "output"])
        writer.writeheader()
        writer.writerows(results)

    # Plot
    plot_path = plot_dose_response(
        [r['strength'] for r in results],
        [r['signature_cosine'] for r in results],
        title="Signature cosine vs. steering strength (manifold)",
        ylabel="Cosine(sim(generated, target))",
        filename="manifold_signature_dose_response.png",
    )

    # Topology/cluster summary
    topo = topology_summary(manifold)

    return {
        'results_csv': csv_path,
        'plot': plot_path,
        'rows': results,
        'topology': topo,
    }


def compute_control_vector_from_examples(arm: ARMMapper, pos_prompts: List[str], neg_prompts: List[str], strength: float):
    control = arm.compute_steering_vector_from_manifold(
        positive_region_indices=list(range(len(pos_prompts))),
        negative_region_indices=list(range(len(pos_prompts), len(pos_prompts) + len(neg_prompts))),
        layer=arm.config.layer_to_probe
    )
    control.coefficient = strength
    return control


def eval_json_adherence(arm: ARMMapper, cfg: EvalConfig) -> Dict[str, Any]:
    # Load fixed exemplar pool and build manifold from all seeds
    with open(cfg.json_seed_file, "r", encoding="utf-8") as f:
        seed_lines = [ln.strip() for ln in f if ln.strip()]

    manifold = arm.map_latent_manifold(seed_lines)

    # Target signature: average across all seeds
    s_norms = [a['resonance_signature']['s_norm'] for a in manifold['seed_analyses']]
    min_len = min(len(s) for s in s_norms)
    target_sig = np.mean(np.stack([s[:min_len] for s in s_norms], axis=0), axis=0)

    # Few-shot prompt prefix sampled from the file
    rng = np.random.default_rng(42)
    k = min(cfg.json_num_shots, len(seed_lines))
    shots = rng.choice(seed_lines, size=k, replace=False)
    examples_block = "\n".join(shots)
    request_prefix = (
        f"Generate JSON similar to the following examples (JSON only):\n{examples_block}\n\n"
        "Task: Given name=Alice, age=30, city=Paris. Respond with exactly: {\"name\":\"Alice\",\"age\":30,\"city\":\"Paris\"}"
    )
    required_keys = ["name", "age", "city"]

    results = []
    for s in cfg.strengths:
        if s > 0:
            # Manifold-signature steering toward the average signature
            text = arm.steer_generation_toward_signature(
                prompt=request_prefix,
                target_signature=target_sig,
                max_length=40,
                temperature=cfg.temperature,
                steering_strength=s,
            )
        else:
            gen = arm.create_controlled_generator()
            text = gen.generate_with_steering(
                prompt=request_prefix,
                max_length=40,
                do_sample=False,
                num_beams=5,
                early_stopping=True,
                no_repeat_ngram_size=2,
            )

        text_for_scoring = text
        if cfg.enable_constrained_json:
            # Keep only JSON-likely chars and extract minimal brace block
            import re
            filtered = re.sub(r"[^\{\}\[\]\:\,\"0-9A-Za-z\s]", "", text)
            import re as _re
            m = _re.search(r"\{[^{}]*\}", filtered, flags=_re.DOTALL)
            text_for_scoring = m.group(0) if m else filtered
        score = safe_json_adherence_score(text_for_scoring, required_keys)
        results.append({
            "strength": s,
            "score": score,
            "output": text,
        })

    # Save CSV
    csv_path = os.path.join(OUTPUT_DIR, "json_adherence_results.csv")
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["strength", "score", "output"])
        writer.writeheader()
        writer.writerows(results)

    # Plot dose–response
    plot_path = plot_dose_response(
        [r["strength"] for r in results],
        [r["score"] for r in results],
        title="JSON adherence vs. steering strength",
        ylabel="Parse & keys present (0/1)",
        filename="json_adherence_dose_response.png",
    )

    return {
        "results_csv": csv_path,
        "plot": plot_path,
        "rows": results,
    }


def eval_style_transfer(arm: ARMMapper, cfg: EvalConfig) -> Dict[str, Any]:
    # Target style markers (example: whimsical/Jabberwocky-like)
    positive_markers = ["gyre", "gimble", "toves", "borogoves", "slithy", "frumious", "jabberwock"]
    negative_markers = ["therefore", "hence", "in conclusion"]

    pos = [
        "Continue in a whimsical, nonsensical, Carroll-like verse style with neologisms.",
        "Write in playful, rhythmic nonsense poetry with invented words.",
    ]
    neg = [
        "Write a dry technical summary with formal tone and no poetry.",
    ]

    # Build manifold for the exemplars
    manifold_prompts = pos + neg
    arm.map_latent_manifold(manifold_prompts)

    request = "The creature lurked in the tulgey wood, and I raised my eyes to speak:"

    results = []
    strengths = list(cfg.strengths)
    for s in strengths:
        gen = arm.create_controlled_generator()
        if s > 0:
            control = arm.compute_steering_vector_from_manifold(
                positive_region_indices=list(range(len(pos))),
                negative_region_indices=list(range(len(pos), len(pos) + len(neg))),
                layer=arm.config.layer_to_probe
            )
            control.coefficient = s
            gen.set_control(control)

        text = gen.generate_with_steering(
            prompt=request,
            max_length=cfg.max_tokens,
            temperature=cfg.temperature,
            do_sample=True,
        )

        score = simple_style_score(text, positive_markers, negative_markers)
        results.append({
            "strength": s,
            "score": score,
            "output": text,
        })

    # Save CSV
    csv_path = os.path.join(OUTPUT_DIR, "style_transfer_results.csv")
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["strength", "score", "output"])
        writer.writeheader()
        writer.writerows(results)

    # Plot dose–response
    plot_path = plot_dose_response(
        [r["strength"] for r in results],
        [r["score"] for r in results],
        title="Style score vs. steering strength",
        ylabel="Heuristic style score",
        filename="style_transfer_dose_response.png",
    )

    return {
        "results_csv": csv_path,
        "plot": plot_path,
        "rows": results,
    }


def main():
    cfg = EvalConfig()
    arm = build_arm(cfg)

    print("Running JSON adherence evaluation...")
    json_res = eval_json_adherence(arm, cfg)
    print(f"CSV: {json_res['results_csv']}")
    print(f"Plot: {json_res['plot']}")

    print("\nRunning style transfer evaluation...")
    style_res = eval_style_transfer(arm, cfg)
    print(f"CSV: {style_res['results_csv']}")
    print(f"Plot: {style_res['plot']}")

    print("\nRunning manifold-signature evaluation...")
    # Reuse style exemplars for manifold evaluation
    pos = [
        "Continue in a whimsical, nonsensical, Carroll-like verse style with neologisms.",
        "Write in playful, rhythmic nonsense poetry with invented words.",
    ]
    neg = [
        "Write a dry technical summary with formal tone and no poetry.",
    ]
    request = "The creature lurked in the tulgey wood, and I raised my eyes to speak:"
    mani_res = eval_manifold_signature(arm, cfg, pos, neg, request, target_idx=0)
    print(f"CSV: {mani_res['results_csv']}")
    print(f"Plot: {mani_res['plot']}")
    topo = mani_res.get('topology', {})
    if topo:
        print(f"Topology: n_clusters={topo.get('n_clusters')}, sizes={topo.get('cluster_sizes')}, silhouette={topo.get('silhouette')}")

    print("\nDone. Check arm_output/ for results and plots.")


if __name__ == "__main__":
    main()


